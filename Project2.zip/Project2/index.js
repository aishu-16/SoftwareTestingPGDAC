


const mongoose = require('mongoose');

mongoose.connect('mongodb://127.0.0.1:27017/cdac')
  .then(() => console.log('Connected!'));

  const Schema=mongoose.Schema;

const userSchema=new Schema({
    name:String,
    email:String,
    pass:String,
    mobile:Number
});

const userModel = mongoose.model('users', userSchema);



const express=require("express")

const app= express()
app.set('view engine','ejs')






// app.get("/",function(req,res)
// {res.send("Index")})

// app.get("/home",function(req,res)
// {res.send("Home")})

// app.get("/login",function(req,res)
// {res.send("Login")
// })

// app.get("/product",function(req,res)
// {res.send("product")})
app.get("/",(re1,res)=>{
    res.render("menu.ejs")
})
app.get("/add" ,(req,res)=>{
    res.render("add.ejs")
})


app.get("/home",function(req,res) {
    res.render("home.ejs")
})

app.get("/show",async function(req,res) {
    // res.render("show.ejs")
var ansDB=await userModel.find()

res.render('show.ejs',{userRecord:ansDB})


})

app.listen(8000)